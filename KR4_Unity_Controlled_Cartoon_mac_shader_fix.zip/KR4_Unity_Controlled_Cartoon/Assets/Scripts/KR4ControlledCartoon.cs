
using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Контрольная работа №4: управляемый мультфильм в Unity.
/// Уникальное произведение: «Кристальный причал и ночной курьер».
/// Сцена полностью процедурная: 2D-фоны, объекты, персонажи и прозрачные RGBA-спрайты
/// создаются кодом при запуске. Внешние картинки не используются.
/// </summary>
public class KR4ControlledCartoon : MonoBehaviour
{
    private const int LAYER_SKY = -100;
    private const int LAYER_FAR = -70;
    private const int LAYER_MID = -35;
    private const int LAYER_FRONT = 5;
    private const int LAYER_ACTOR = 35;
    private const int LAYER_UI_WORLD = 80;

    // Визуальные слои задаются через sortingOrder SpriteRenderer.
    // Дорожка остается под курьером, курьер свободно едет без столкновений,
    // а столбы/перила и большие кусты отрисовываются поверх него, чтобы при проезде
    // курьер визуально уходил за передние объекты, но продолжал ехать.
    private const int VISUAL_LAYER_COURIER_ROAD = 55;
    // Визуальный слой 1: курьер двигается за большими кустами и столбом.
    private const int VISUAL_LAYER_COURIER_1 = 72;
    // Большие нижние кусты: слой выше курьера, поэтому курьер проезжает за ними.
    private const int VISUAL_LAYER_BUSH_IN_FRONT_OF_COURIER = 118;
    // Визуальный слой 2: столб и перила всегда отображаются перед курьером и кустами.
    private const int VISUAL_LAYER_POST_2 = 160;

    private const float COURIER_MIN_X = -12.4f;
    private const float COURIER_MAX_X = 12.4f;

    private readonly List<CartoonLayer> layers = new List<CartoonLayer>();
    private readonly List<CartoonActor> actors = new List<CartoonActor>();
    private readonly List<SpriteRenderer> dayTintObjects = new List<SpriteRenderer>();
    private readonly List<Transform> lanterns = new List<Transform>();
    private readonly List<Transform> clouds = new List<Transform>();
    private readonly List<Transform> waterBands = new List<Transform>();

    private GameObject sceneRoot;
    private Camera sceneCamera;
    private Sprite rectSprite;
    private Sprite circleSprite;
    private Sprite triangleSprite;
    private Sprite diamondSprite;
    private Sprite softCircleSprite;
    private Material safeSpriteMaterial;

    private float runningTime;
    private float viewX = 0.0f;
    private float viewY = 0.0f;
    private float courierSpeed = 1.0f;
    private float catSpeed = 0.72f;
    private float birdSpeed = 0.92f;
    private float lanternWind = 0.55f;
    private float globalScale = 1.0f;
    private float dayNight = 0.18f;
    private float animationTempo = 1.0f;
    private bool demoMode = false;
    private bool paused = false;
    private bool showHelp = true;
    private bool showDepthGuides = true;

    // Курьер передвигается только с клавиатуры. Ползунки и демонстрационный режим
    // не меняют его координаты: они лишь настраивают сцену и других персонажей.
    private Vector2 courierKeyboardOffset = Vector2.zero;
    private float courierKeyboardDirection = 1f;
    private float courierKeyboardActivity = 0f;
    private float courierKeyboardSpin = 0f;
    private float courierJumpHeight = 0f;
    private float courierJumpVelocity = 0f;
    private bool courierGrounded = true;
    private const float COURIER_KEYBOARD_BASE_SPEED = 3.8f;
    private const float COURIER_JUMP_START_SPEED = 6.2f;
    private const float COURIER_JUMP_GRAVITY = 18.0f;

    private GUIStyle smallStyle;
    private GUIStyle titleStyle;
    private GUIStyle valueStyle;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void AutoCreateOnPlay()
    {
        if (FindObjectOfType<KR4ControlledCartoon>() == null)
        {
            GameObject host = new GameObject("КР4 Unity — управляемый мультфильм");
            host.AddComponent<KR4ControlledCartoon>();
        }
    }

    private void Awake()
    {
        Application.targetFrameRate = 60;
        BuildScene();
    }

    private void Update()
    {
        float dt = paused ? 0f : Time.deltaTime;
        runningTime += dt;
        HandleCourierKeyboard(dt);
        if (demoMode && !paused) ApplyDemoControl(dt);
        UpdateParallax(dt);
        UpdateProceduralAnimation(dt);
        UpdateActors(dt);
        UpdateLightingAndCamera(dt);
    }

    private void BuildScene()
    {
        sceneRoot = new GameObject("Уникальное произведение — Кристальный причал и ночной курьер");
        sceneRoot.transform.SetParent(transform, false);

        rectSprite = MakeRectSprite(C("#FFFFFFFF"));
        circleSprite = MakeCircleSprite(96, C("#FFFFFFFF"), 0.0f);
        softCircleSprite = MakeCircleSprite(128, C("#FFFFFFFF"), 0.35f);
        triangleSprite = MakeTriangleSprite(96, C("#FFFFFFFF"));
        diamondSprite = MakeDiamondSprite(96, C("#FFFFFFFF"));

        ConfigureCamera();

        CartoonLayer sky = CreateLayer("Фон 1 — дальнее небо", 0.10f);
        CartoonLayer far = CreateLayer("Фон 2 — дальний кристальный город", 0.28f);
        CartoonLayer middle = CreateLayer("Средний план — причал, башни, объекты", 0.62f);
        CartoonLayer front = CreateLayer("Передний план — мостки и близкие предметы", 1.00f);

        BuildSkyLayer(sky.root.transform);
        BuildFarLayer(far.root.transform);
        BuildMiddleLayer(middle.root.transform);
        BuildFrontLayer(front.root.transform);
        BuildCharacters(middle.root.transform, front.root.transform, far.root.transform);
    }

    private void ConfigureCamera()
    {
        sceneCamera = Camera.main;
        if (sceneCamera == null)
        {
            GameObject cameraObject = new GameObject("Main Camera");
            sceneCamera = cameraObject.AddComponent<Camera>();
            cameraObject.tag = "MainCamera";
        }
        sceneCamera.orthographic = true;
        sceneCamera.orthographicSize = 5.5f;
        sceneCamera.transform.position = new Vector3(0f, 0f, -10f);
        sceneCamera.clearFlags = CameraClearFlags.SolidColor;
        sceneCamera.backgroundColor = C("#07102AFF");
    }

    private CartoonLayer CreateLayer(string name, float parallax)
    {
        CartoonLayer layer = new CartoonLayer();
        layer.root = new GameObject(name);
        layer.root.transform.SetParent(sceneRoot.transform, false);
        layer.parallax = parallax;
        layer.basePosition = Vector2.zero;
        layers.Add(layer);
        return layer;
    }

    private void BuildSkyLayer(Transform parent)
    {
        Sprite gradient = MakeVerticalGradientSprite(64, 64, C("#06112DFF"), C("#264B86FF"));
        SpriteRenderer sky = AddSprite(parent, "градиентное небо", gradient, new Vector2(0f, 0f), new Vector2(34f, 13f), Color.white, LAYER_SKY);
        dayTintObjects.Add(sky);

        AddEllipse(parent, "луна-сапфир", new Vector2(-6.7f, 3.55f), new Vector2(1.25f, 1.25f), C("#EAF7FFFF"), LAYER_SKY + 1);
        AddEllipse(parent, "кратер 1", new Vector2(-6.35f, 3.72f), new Vector2(0.22f, 0.18f), C("#BBD3E4AA"), LAYER_SKY + 2);
        AddEllipse(parent, "кратер 2", new Vector2(-6.88f, 3.33f), new Vector2(0.16f, 0.12f), C("#AFC7DCAA"), LAYER_SKY + 2);

        // Звезды и созвездие в форме ключа: уникальная декоративная деталь.
        for (int i = 0; i < 48; i++)
        {
            float x = -15.5f + (i * 2.17f) % 31f;
            float y = 0.2f + Mathf.Abs(Mathf.Sin(i * 4.13f)) * 5.0f;
            float s = 0.035f + (i % 5) * 0.012f;
            AddEllipse(parent, "звезда_" + i, new Vector2(x, y), new Vector2(s, s), C("#F6FBFFFF"), LAYER_SKY + 3);
        }
        AddRect(parent, "созвездие_ключ_1", new Vector2(4.1f, 4.25f), new Vector2(0.85f, 0.025f), C("#BFE8FFFF"), LAYER_SKY + 4, 23f);
        AddRect(parent, "созвездие_ключ_2", new Vector2(4.78f, 4.48f), new Vector2(0.50f, 0.025f), C("#BFE8FFFF"), LAYER_SKY + 4, -18f);
        AddEllipse(parent, "созвездие_кольцо", new Vector2(3.65f, 4.07f), new Vector2(0.18f, 0.18f), C("#BFE8FFFF"), LAYER_SKY + 5);

        // Облака — отдельные объекты, медленно двигаются и тоже участвуют в параллаксе.
        for (int i = 0; i < 4; i++)
        {
            GameObject cloud = new GameObject("медленное облако_" + i);
            cloud.transform.SetParent(parent, false);
            cloud.transform.localPosition = new Vector3(-9f + i * 6.2f, 2.0f + Mathf.Sin(i) * 0.5f, 0f);
            clouds.Add(cloud.transform);
            AddEllipse(cloud.transform, "пятно_а", new Vector2(0f, 0f), new Vector2(1.3f, 0.32f), C("#B7D9F34D"), LAYER_SKY + 5);
            AddEllipse(cloud.transform, "пятно_б", new Vector2(0.55f, 0.08f), new Vector2(0.95f, 0.30f), C("#C7E4FA44"), LAYER_SKY + 5);
            AddEllipse(cloud.transform, "пятно_в", new Vector2(-0.55f, 0.05f), new Vector2(0.80f, 0.24f), C("#CDE9FF33"), LAYER_SKY + 5);
        }
    }

    private void BuildFarLayer(Transform parent)
    {
        AddRect(parent, "дальний горизонт воды", new Vector2(0f, -2.75f), new Vector2(34f, 1.0f), C("#123A61FF"), LAYER_FAR);
        for (int i = 0; i < 8; i++)
        {
            Transform band = AddRect(parent, "блик далекой воды_" + i, new Vector2(-14f + i * 4.4f, -2.55f + (i % 3) * 0.16f), new Vector2(2.2f, 0.035f), C("#79C9F755"), LAYER_FAR + 1).transform;
            waterBands.Add(band);
        }

        // Горный фон и кристаллический город: два самостоятельных слоя внутри дальнего фона.
        for (int i = 0; i < 7; i++)
        {
            float x = -14f + i * 4.6f;
            float h = 1.1f + Mathf.Abs(Mathf.Sin(i * 1.7f)) * 1.3f;
            AddTriangle(parent, "дальний кристалл_" + i, new Vector2(x, -1.48f + h * 0.45f), new Vector2(2.2f, h), C("#1E3D73DD"), LAYER_FAR + 2, i % 2 == 0 ? 0f : 8f);
            AddTriangle(parent, "подсветка кристалла_" + i, new Vector2(x + 0.2f, -1.1f + h * 0.55f), new Vector2(0.6f, h * 0.7f), C("#6FE7FF44"), LAYER_FAR + 3, -12f);
        }
        for (int i = 0; i < 9; i++)
        {
            float x = -12.5f + i * 3.1f;
            float h = 1.0f + (i % 4) * 0.38f;
            AddRect(parent, "силуэт башни_" + i, new Vector2(x, -1.7f + h / 2f), new Vector2(0.5f + (i % 2) * 0.25f, h), C("#0B224CFF"), LAYER_FAR + 4);
            AddTriangle(parent, "крыша башни_" + i, new Vector2(x, -1.1f + h), new Vector2(0.85f, 0.6f), C("#102E62FF"), LAYER_FAR + 5);
        }

        // Дальние аэростаты — промежуточные движущиеся объекты.
        for (int i = 0; i < 3; i++)
        {
            GameObject ship = new GameObject("дальний световой дирижабль_" + i);
            ship.transform.SetParent(parent, false);
            ship.transform.localPosition = new Vector3(-9f + i * 7.5f, 1.0f + i * 0.45f, 0f);
            lanterns.Add(ship.transform);
            AddEllipse(ship.transform, "оболочка", new Vector2(0f, 0.15f), new Vector2(1.4f, 0.44f), C("#FFD37CBB"), LAYER_FAR + 20);
            AddRect(ship.transform, "гондола", new Vector2(0f, -0.18f), new Vector2(0.55f, 0.13f), C("#5A3A3AFF"), LAYER_FAR + 21);
            AddRect(ship.transform, "нить", new Vector2(0f, -0.04f), new Vector2(0.03f, 0.23f), C("#F8E6BBAA"), LAYER_FAR + 21);
        }
    }

    private void BuildMiddleLayer(Transform parent)
    {
        AddRect(parent, "средний слой воды", new Vector2(0f, -3.55f), new Vector2(34f, 1.2f), C("#155071FF"), LAYER_MID);
        for (int i = 0; i < 9; i++)
        {
            Transform band = AddRect(parent, "блик воды средний_" + i, new Vector2(-15f + i * 3.8f, -3.15f + (i % 4) * 0.12f), new Vector2(2.3f, 0.045f), C("#9FE6F966"), LAYER_MID + 2).transform;
            waterBands.Add(band);
        }

        // Платформа причала.
        AddRect(parent, "причал средний настил", new Vector2(0f, -2.35f), new Vector2(14.2f, 0.35f), C("#7B5538FF"), LAYER_MID + 8);
        for (int i = 0; i < 11; i++)
        {
            AddRect(parent, "доска причала_" + i, new Vector2(-6.6f + i * 1.32f, -2.18f), new Vector2(0.08f, 0.36f), C("#5C3825FF"), LAYER_MID + 9);
        }

        // Ровная дорожка для курьера. Она находится в том же параллакс-слое, что и курьер,
        // поэтому при управлении камерой поверхность не «уезжает» из-под колеса.
        AddRect(parent, "ровная поверхность для езды курьера", new Vector2(0f, -2.55f), new Vector2(27.0f, 0.18f), C("#B77746FF"), VISUAL_LAYER_COURIER_ROAD);
        AddRect(parent, "светлая кромка ровной поверхности", new Vector2(0f, -2.44f), new Vector2(27.0f, 0.035f), C("#E0A263FF"), VISUAL_LAYER_COURIER_ROAD + 1);

        // Большие кусты расположены ниже по сцене и находятся на слое перед курьером:
        // курьер может проехать через их координаты без столкновений, но визуально проходит за листвой.
        BuildBushInFrontOfCourier(parent, "большой куст перед курьером левый", new Vector2(-2.55f, -2.92f), 1.62f);
        BuildBushInFrontOfCourier(parent, "большой куст перед курьером правый", new Vector2(2.95f, -2.94f), 1.82f);
        BuildBushInFrontOfCourier(parent, "большой нижний куст перед курьером", new Vector2(8.65f, -2.98f), 1.48f);

        // Опоры оставлены как отдельные передние перекрывающие объекты: курьер может
        // проехать через их координату, но визуально столб остается перед ним.
        AddRect(parent, "левая опора — перед курьером", new Vector2(-5.2f, -3.05f), new Vector2(0.22f, 1.3f), C("#4B332AFF"), VISUAL_LAYER_POST_2);
        AddRect(parent, "правая опора — перед курьером", new Vector2(5.2f, -3.05f), new Vector2(0.22f, 1.3f), C("#4B332AFF"), VISUAL_LAYER_POST_2);

        // Центральные объекты между задним и передним фоном.
        BuildCrystalCrane(parent, new Vector2(-4.8f, -0.95f));
        BuildLighthouse(parent, new Vector2(4.55f, -1.0f));
        BuildMarketStall(parent, new Vector2(0.4f, -1.55f));

        // Светящиеся фонари и рыба-указатель.
        for (int i = 0; i < 7; i++)
        {
            GameObject lantern = new GameObject("подвесной фонарь_" + i);
            lantern.transform.SetParent(parent, false);
            lantern.transform.localPosition = new Vector3(-6.0f + i * 1.95f, 0.2f + Mathf.Sin(i * 0.7f) * 0.35f, 0f);
            lanterns.Add(lantern.transform);
            AddRect(lantern.transform, "нить", new Vector2(0f, 0.28f), new Vector2(0.025f, 0.42f), C("#D8EFFFFF"), LAYER_MID + 24);
            AddEllipse(lantern.transform, "свет", new Vector2(0f, 0f), new Vector2(0.34f, 0.42f), C("#FFD86ECC"), LAYER_MID + 25);
            AddEllipse(lantern.transform, "ореол", new Vector2(0f, 0f), new Vector2(0.88f, 0.88f), C("#FFEBAA24"), LAYER_MID + 23);
        }
    }

    private void BuildBushInFrontOfCourier(Transform parent, string name, Vector2 basePosition, float scale)
    {
        GameObject bush = new GameObject(name + " — передний слой, курьер едет за кустом");
        bush.transform.SetParent(parent, false);
        bush.transform.localPosition = new Vector3(basePosition.x, basePosition.y, 0f);
        bush.transform.localScale = Vector3.one * scale;

        AddEllipse(bush.transform, "широкая тень куста", new Vector2(0f, -0.20f), new Vector2(1.85f, 0.26f), C("#00000042"), VISUAL_LAYER_BUSH_IN_FRONT_OF_COURIER - 3);
        AddRect(bush.transform, "низкие ветки", new Vector2(0f, -0.02f), new Vector2(1.22f, 0.08f), C("#2F5D35FF"), VISUAL_LAYER_BUSH_IN_FRONT_OF_COURIER - 1, 8f);
        AddEllipse(bush.transform, "крупная листва 1", new Vector2(-0.54f, 0.00f), new Vector2(0.92f, 0.58f), C("#2F8C4DFF"), VISUAL_LAYER_BUSH_IN_FRONT_OF_COURIER);
        AddEllipse(bush.transform, "крупная листва 2", new Vector2(0.00f, 0.16f), new Vector2(1.08f, 0.72f), C("#3BAA5EFF"), VISUAL_LAYER_BUSH_IN_FRONT_OF_COURIER + 1);
        AddEllipse(bush.transform, "крупная листва 3", new Vector2(0.58f, 0.02f), new Vector2(0.90f, 0.56f), C("#267A45FF"), VISUAL_LAYER_BUSH_IN_FRONT_OF_COURIER + 2);
        AddEllipse(bush.transform, "верхняя листва", new Vector2(-0.12f, 0.43f), new Vector2(0.72f, 0.40f), C("#47BC67FF"), VISUAL_LAYER_BUSH_IN_FRONT_OF_COURIER + 3);
        AddEllipse(bush.transform, "светлая листва", new Vector2(0.18f, 0.34f), new Vector2(0.52f, 0.30f), C("#73D982DD"), VISUAL_LAYER_BUSH_IN_FRONT_OF_COURIER + 4);
        AddEllipse(bush.transform, "ягода 1", new Vector2(-0.24f, 0.30f), new Vector2(0.10f, 0.10f), C("#FFD66BFF"), VISUAL_LAYER_BUSH_IN_FRONT_OF_COURIER + 5);
        AddEllipse(bush.transform, "ягода 2", new Vector2(0.40f, 0.18f), new Vector2(0.09f, 0.09f), C("#FFD66BFF"), VISUAL_LAYER_BUSH_IN_FRONT_OF_COURIER + 5);
        AddEllipse(bush.transform, "ягода 3", new Vector2(0.06f, 0.50f), new Vector2(0.08f, 0.08f), C("#FFD66BFF"), VISUAL_LAYER_BUSH_IN_FRONT_OF_COURIER + 5);
    }

    private void BuildFrontLayer(Transform parent)
    {
        AddRect(parent, "передний мостик", new Vector2(0f, -4.35f), new Vector2(34f, 1.1f), C("#3A241EFF"), LAYER_FRONT + 4);
        for (int i = 0; i < 18; i++)
        {
            AddRect(parent, "широкая доска переднего плана_" + i, new Vector2(-16f + i * 1.9f, -3.95f), new Vector2(1.55f, 0.12f), C(i % 2 == 0 ? "#7C523AFF" : "#69442FFF"), LAYER_FRONT + 6, -5f + i % 3 * 4f);
        }
        AddRect(parent, "перила переднего плана — перед курьером", new Vector2(0f, -3.35f), new Vector2(32f, 0.12f), C("#A97142FF"), VISUAL_LAYER_POST_2);
        for (int i = 0; i < 9; i++)
        {
            AddRect(parent, "стойка перил перед курьером_" + i, new Vector2(-14f + i * 3.5f, -3.65f), new Vector2(0.16f, 0.85f), C("#8A5A3DFF"), VISUAL_LAYER_POST_2);
        }
        AddRect(parent, "ящик ближний", new Vector2(-7.5f, -3.10f), new Vector2(1.25f, 0.65f), C("#5D3B2CFF"), LAYER_FRONT + 13);
        AddRect(parent, "крышка ящика", new Vector2(-7.5f, -2.73f), new Vector2(1.35f, 0.14f), C("#9B6742FF"), LAYER_FRONT + 14);
        AddEllipse(parent, "большая катушка", new Vector2(7.4f, -3.2f), new Vector2(0.9f, 0.9f), C("#5F4638FF"), LAYER_FRONT + 13);
        AddEllipse(parent, "отверстие катушки", new Vector2(7.4f, -3.2f), new Vector2(0.28f, 0.28f), C("#2B1E1AFF"), LAYER_FRONT + 14);
    }

    private void BuildCrystalCrane(Transform parent, Vector2 basePosition)
    {
        GameObject crane = new GameObject("объект: кристальный кран");
        crane.transform.SetParent(parent, false);
        crane.transform.localPosition = basePosition;
        AddRect(crane.transform, "опора", new Vector2(0f, 0.7f), new Vector2(0.22f, 2.6f), C("#465F77FF"), LAYER_MID + 15);
        AddRect(crane.transform, "стрела", new Vector2(1.0f, 1.9f), new Vector2(2.5f, 0.16f), C("#698AA5FF"), LAYER_MID + 16, -12f);
        AddRect(crane.transform, "трос", new Vector2(2.1f, 1.2f), new Vector2(0.035f, 1.0f), C("#A7C5DAFF"), LAYER_MID + 17);
        AddDiamond(crane.transform, "подвешенный кристалл", new Vector2(2.1f, 0.42f), new Vector2(0.58f, 0.74f), C("#55F7FFAA"), LAYER_MID + 18);
        AddEllipse(crane.transform, "свет кристалла", new Vector2(2.1f, 0.42f), new Vector2(1.1f, 1.1f), C("#55F7FF22"), LAYER_MID + 17);
    }

    private void BuildLighthouse(Transform parent, Vector2 basePosition)
    {
        GameObject tower = new GameObject("объект: маяк-парус");
        tower.transform.SetParent(parent, false);
        tower.transform.localPosition = basePosition;
        AddRect(tower.transform, "башня", new Vector2(0f, 0.6f), new Vector2(0.72f, 2.5f), C("#C76E4AFF"), LAYER_MID + 15);
        AddRect(tower.transform, "полоса 1", new Vector2(0f, 0.15f), new Vector2(0.78f, 0.16f), C("#FFE0A8FF"), LAYER_MID + 16);
        AddRect(tower.transform, "полоса 2", new Vector2(0f, 0.85f), new Vector2(0.78f, 0.16f), C("#FFE0A8FF"), LAYER_MID + 16);
        AddTriangle(tower.transform, "крыша", new Vector2(0f, 2.05f), new Vector2(1.25f, 0.8f), C("#552F46FF"), LAYER_MID + 17);
        AddEllipse(tower.transform, "линза", new Vector2(0f, 1.45f), new Vector2(0.42f, 0.42f), C("#B9F7FFFF"), LAYER_MID + 18);
        AddTriangle(tower.transform, "луч", new Vector2(-1.15f, 1.45f), new Vector2(2.2f, 0.65f), C("#B9F7FF25"), LAYER_MID + 14, 90f);
    }

    private void BuildMarketStall(Transform parent, Vector2 basePosition)
    {
        GameObject stall = new GameObject("объект: киоск с картами ветра");
        stall.transform.SetParent(parent, false);
        stall.transform.localPosition = basePosition;
        AddRect(stall.transform, "корпус", new Vector2(0f, 0f), new Vector2(1.9f, 1.1f), C("#603B2DFF"), LAYER_MID + 15);
        AddRect(stall.transform, "прилавок", new Vector2(0f, -0.25f), new Vector2(2.1f, 0.18f), C("#B77946FF"), LAYER_MID + 17);
        AddTriangle(stall.transform, "тент", new Vector2(0f, 0.8f), new Vector2(2.3f, 1.0f), C("#D54B6AFF"), LAYER_MID + 18, 180f);
        for (int i = 0; i < 4; i++)
            AddRect(stall.transform, "полоса тента_" + i, new Vector2(-0.75f + i * 0.5f, 0.63f), new Vector2(0.25f, 0.55f), C(i % 2 == 0 ? "#FFE09BFF" : "#D54B6AFF"), LAYER_MID + 19);
    }

    private void BuildCharacters(Transform middleParent, Transform frontParent, Transform farParent)
    {
        CartoonActor courier = CreateActor("Курьер на моноколесе", "courier", middleParent, new Vector2(-4f, -2.1f), 26.0f, 0f);
        CartoonActor cat = CreateActor("Кот-робот инспектор", "cat", frontParent, new Vector2(4f, -3.0f), 17f, 2.4f);
        CartoonActor bird = CreateActor("Птица-дрон картограф", "bird", farParent, new Vector2(1.5f, 1.3f), 19f, 4.1f);
        actors.Add(courier);
        actors.Add(cat);
        actors.Add(bird);
    }

    private CartoonActor CreateActor(string name, string kind, Transform parent, Vector2 basePosition, float pathWidth, float phaseOffset)
    {
        CartoonActor actor = new CartoonActor();
        actor.name = name;
        actor.kind = kind;
        actor.root = new GameObject("персонаж: " + name);
        actor.root.transform.SetParent(parent, false);
        actor.root.transform.localPosition = basePosition;
        actor.basePosition = basePosition;
        actor.pathWidth = pathWidth;
        actor.phaseOffset = phaseOffset;
        actor.parts = new Dictionary<string, Transform>();

        if (kind == "courier") BuildCourierParts(actor);
        else if (kind == "cat") BuildCatParts(actor);
        else BuildBirdParts(actor);

        return actor;
    }

    private void BuildCourierParts(CartoonActor actor)
    {
        Transform r = actor.root.transform;
        actor.parts["wheel"] = AddEllipse(r, "моноколесо", new Vector2(0f, -0.10f), new Vector2(0.72f, 0.72f), C("#20242FFF"), VISUAL_LAYER_COURIER_1).transform;
        actor.parts["wheelLight"] = AddEllipse(r, "свет колеса", new Vector2(0f, -0.10f), new Vector2(0.42f, 0.42f), C("#68E4FFFF"), VISUAL_LAYER_COURIER_1 + 1).transform;
        actor.parts["board"] = AddRect(r, "платформа", new Vector2(0f, 0.22f), new Vector2(1.1f, 0.12f), C("#E4B256FF"), VISUAL_LAYER_COURIER_1 + 2, 0f).transform;
        actor.parts["body"] = AddRect(r, "куртка", new Vector2(0f, 0.90f), new Vector2(0.48f, 0.85f), C("#2E9AD0FF"), VISUAL_LAYER_COURIER_1 + 4, -5f).transform;
        actor.parts["head"] = AddEllipse(r, "голова", new Vector2(0.03f, 1.47f), new Vector2(0.42f, 0.42f), C("#FFD3A3FF"), VISUAL_LAYER_COURIER_1 + 5).transform;
        actor.parts["cap"] = AddRect(r, "шапка", new Vector2(0.05f, 1.72f), new Vector2(0.52f, 0.12f), C("#FF617DFF"), VISUAL_LAYER_COURIER_1 + 6, -7f).transform;
        actor.parts["armA"] = AddRect(r, "левая рука", new Vector2(-0.34f, 0.95f), new Vector2(0.14f, 0.65f), C("#2E9AD0FF"), VISUAL_LAYER_COURIER_1 + 3, -35f).transform;
        actor.parts["armB"] = AddRect(r, "правая рука", new Vector2(0.34f, 0.95f), new Vector2(0.14f, 0.65f), C("#2E9AD0FF"), VISUAL_LAYER_COURIER_1 + 3, 35f).transform;
        actor.parts["legA"] = AddRect(r, "левая нога", new Vector2(-0.18f, 0.35f), new Vector2(0.14f, 0.62f), C("#263A66FF"), VISUAL_LAYER_COURIER_1 + 3, 25f).transform;
        actor.parts["legB"] = AddRect(r, "правая нога", new Vector2(0.18f, 0.35f), new Vector2(0.14f, 0.62f), C("#263A66FF"), VISUAL_LAYER_COURIER_1 + 3, -25f).transform;
        actor.parts["scarf"] = AddRect(r, "шарф", new Vector2(-0.42f, 1.32f), new Vector2(0.82f, 0.10f), C("#FFD24DFF"), VISUAL_LAYER_COURIER_1 + 6, -15f).transform;
    }

    private void BuildCatParts(CartoonActor actor)
    {
        Transform r = actor.root.transform;
        actor.parts["shadow"] = AddEllipse(r, "тень кота", new Vector2(0f, -0.18f), new Vector2(1.4f, 0.22f), C("#00000045"), LAYER_ACTOR - 1).transform;
        actor.parts["body"] = AddEllipse(r, "корпус кота", new Vector2(0f, 0.30f), new Vector2(0.95f, 0.52f), C("#8899A8FF"), LAYER_ACTOR + 3).transform;
        actor.parts["head"] = AddEllipse(r, "голова кота", new Vector2(0.52f, 0.60f), new Vector2(0.50f, 0.45f), C("#B3C2CFFF"), LAYER_ACTOR + 4).transform;
        actor.parts["earA"] = AddTriangle(r, "ухо 1", new Vector2(0.37f, 0.91f), new Vector2(0.26f, 0.32f), C("#B3C2CFFF"), LAYER_ACTOR + 5, -12f).transform;
        actor.parts["earB"] = AddTriangle(r, "ухо 2", new Vector2(0.65f, 0.91f), new Vector2(0.26f, 0.32f), C("#B3C2CFFF"), LAYER_ACTOR + 5, 12f).transform;
        actor.parts["eye"] = AddEllipse(r, "светящийся глаз", new Vector2(0.66f, 0.62f), new Vector2(0.12f, 0.12f), C("#45FFF1FF"), LAYER_ACTOR + 6).transform;
        actor.parts["tail"] = AddRect(r, "антенна-хвост", new Vector2(-0.55f, 0.60f), new Vector2(0.12f, 0.78f), C("#8899A8FF"), LAYER_ACTOR + 2, -58f).transform;
        actor.parts["legA"] = AddRect(r, "лапа 1", new Vector2(-0.32f, -0.03f), new Vector2(0.12f, 0.38f), C("#697986FF"), LAYER_ACTOR + 2, 8f).transform;
        actor.parts["legB"] = AddRect(r, "лапа 2", new Vector2(0.03f, -0.02f), new Vector2(0.12f, 0.38f), C("#697986FF"), LAYER_ACTOR + 2, -8f).transform;
        actor.parts["legC"] = AddRect(r, "лапа 3", new Vector2(0.36f, -0.03f), new Vector2(0.12f, 0.38f), C("#697986FF"), LAYER_ACTOR + 2, 8f).transform;
    }

    private void BuildBirdParts(CartoonActor actor)
    {
        Transform r = actor.root.transform;
        actor.parts["body"] = AddEllipse(r, "корпус птицы-дрона", new Vector2(0f, 0f), new Vector2(0.60f, 0.38f), C("#FFB15EFF"), LAYER_ACTOR).transform;
        actor.parts["head"] = AddEllipse(r, "голова", new Vector2(0.38f, 0.08f), new Vector2(0.28f, 0.25f), C("#FFD079FF"), LAYER_ACTOR + 1).transform;
        actor.parts["eye"] = AddEllipse(r, "линза", new Vector2(0.47f, 0.12f), new Vector2(0.08f, 0.08f), C("#1A2A4AFF"), LAYER_ACTOR + 2).transform;
        actor.parts["wingA"] = AddTriangle(r, "крыло верхнее", new Vector2(-0.08f, 0.13f), new Vector2(0.9f, 0.42f), C("#F06D8DFF"), LAYER_ACTOR - 1, 18f).transform;
        actor.parts["wingB"] = AddTriangle(r, "крыло нижнее", new Vector2(-0.08f, -0.12f), new Vector2(0.9f, 0.42f), C("#F06D8DFF"), LAYER_ACTOR - 1, 162f).transform;
        actor.parts["tail"] = AddTriangle(r, "хвост", new Vector2(-0.42f, 0f), new Vector2(0.38f, 0.38f), C("#D94C70FF"), LAYER_ACTOR - 1, -90f).transform;
    }

    private void BuildWorldLabels(Transform parent)
    {
        // Экранные подписи на фоне убраны: текст остается только в окне управления.
    }

    private void HandleCourierKeyboard(float dt)
    {
        if (dt <= 0f) return;

        float moveX = 0f;
        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) moveX -= 1f;
        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) moveX += 1f;

        bool jumpPressed = Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow);
        if (jumpPressed && courierGrounded)
        {
            courierGrounded = false;
            courierJumpVelocity = COURIER_JUMP_START_SPEED;
            courierKeyboardActivity = 0.45f;
        }

        if (Mathf.Abs(moveX) > 0.001f)
        {
            float boost = (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift)) ? 1.75f : 1f;
            float speedMultiplier = Mathf.Max(0.25f, courierSpeed);
            courierKeyboardOffset.x += moveX * COURIER_KEYBOARD_BASE_SPEED * speedMultiplier * boost * dt;
            // Ограничение задано по общим границам дорожки, а не по столбам/декору:
            // курьер может проезжать через место, где визуально стоит столб,
            // а столб отрисовывается поверх курьера как передний перекрывающий слой.
            courierKeyboardOffset.x = Mathf.Clamp(courierKeyboardOffset.x, COURIER_MIN_X + 4f, COURIER_MAX_X + 4f);
            courierKeyboardActivity = 0.35f;
            courierKeyboardDirection = Mathf.Sign(moveX);
            courierKeyboardSpin += moveX * 360f * boost * speedMultiplier * dt;
        }
        else
        {
            courierKeyboardActivity = Mathf.Max(0f, courierKeyboardActivity - dt);
        }

        if (!courierGrounded)
        {
            courierJumpHeight += courierJumpVelocity * dt;
            courierJumpVelocity -= COURIER_JUMP_GRAVITY * dt;

            if (courierJumpHeight <= 0f)
            {
                courierJumpHeight = 0f;
                courierJumpVelocity = 0f;
                courierGrounded = true;
            }
        }

        if (Input.GetKeyDown(KeyCode.Home))
        {
            courierKeyboardOffset = Vector2.zero;
            courierKeyboardActivity = 0f;
            courierJumpHeight = 0f;
            courierJumpVelocity = 0f;
            courierGrounded = true;
        }
    }

    private void UpdateParallax(float dt)
    {
        foreach (CartoonLayer layer in layers)
        {
            Vector3 target = new Vector3(-viewX * layer.parallax, -viewY * layer.parallax * 0.55f, 0f);
            layer.root.transform.localPosition = Vector3.Lerp(layer.root.transform.localPosition, target, 1f - Mathf.Exp(-dt * 9f));
        }
        sceneRoot.transform.localScale = Vector3.one * globalScale;
    }

    private void UpdateProceduralAnimation(float dt)
    {
        for (int i = 0; i < lanterns.Count; i++)
        {
            Transform t = lanterns[i];
            Vector3 p = t.localPosition;
            p.y += Mathf.Sin(runningTime * (0.8f + lanternWind) + i * 1.7f) * dt * 0.22f;
            p.x += Mathf.Cos(runningTime * (0.35f + lanternWind * 0.25f) + i) * dt * 0.18f * lanternWind;
            if (p.x > 12f) p.x = -12f;
            if (p.x < -12f) p.x = 12f;
            t.localPosition = p;
            t.localRotation = Quaternion.Euler(0f, 0f, Mathf.Sin(runningTime * 1.4f + i) * 5.0f);
        }

        for (int i = 0; i < clouds.Count; i++)
        {
            Transform t = clouds[i];
            Vector3 p = t.localPosition;
            p.x += dt * (0.10f + i * 0.025f) * (0.3f + lanternWind);
            if (p.x > 15f) p.x = -15f;
            t.localPosition = p;
        }

        for (int i = 0; i < waterBands.Count; i++)
        {
            Transform t = waterBands[i];
            Vector3 p = t.localPosition;
            p.x += dt * (0.28f + (i % 3) * 0.08f);
            if (p.x > 16f) p.x = -16f;
            t.localPosition = p;
        }
    }

    private void UpdateActors(float dt)
    {
        foreach (CartoonActor actor in actors)
        {
            if (actor.kind == "courier") UpdateCourier(actor, courierSpeed);
            else if (actor.kind == "cat") UpdateCat(actor, catSpeed);
            else UpdateBird(actor, birdSpeed);
        }
    }

    private void UpdateCourier(CartoonActor actor, float speed)
    {
        // Движение курьера берется только из courierKeyboardOffset.x, который изменяется
        // в HandleCourierKeyboard. Автоматической траектории здесь нет.
        float motionLevel = courierKeyboardActivity > 0f ? 1f : 0f;
        if (!courierGrounded) motionLevel = 1f;

        float phaseFloat = Mathf.Repeat(runningTime * Mathf.Max(0.35f, courierSpeed) * animationTempo * 8f + actor.phaseOffset, 8f);
        int frame = Mathf.FloorToInt(phaseFloat);
        float pose = motionLevel * Mathf.Sin(frame / 8f * Mathf.PI * 2f);
        float pose2 = motionLevel * Mathf.Cos(frame / 8f * Mathf.PI * 2f);

        float x = actor.basePosition.x + courierKeyboardOffset.x;
        x = Mathf.Clamp(x, COURIER_MIN_X, COURIER_MAX_X);
        float walkBob = courierGrounded ? Mathf.Abs(pose) * 0.08f : 0f;
        float y = actor.basePosition.y + courierJumpHeight + walkBob;
        actor.root.transform.localPosition = new Vector3(x, y, 0f);

        actor.root.transform.localScale = new Vector3(courierKeyboardDirection * 0.88f, 0.88f, 1f);
        actor.parts["wheel"].localRotation = Quaternion.Euler(0f, 0f, -courierKeyboardSpin);
        actor.parts["wheelLight"].localRotation = Quaternion.Euler(0f, 0f, courierKeyboardSpin * 0.6f);
        actor.parts["body"].localRotation = Quaternion.Euler(0f, 0f, -4f + pose * 4f - (courierGrounded ? 0f : 6f));
        actor.parts["armA"].localRotation = Quaternion.Euler(0f, 0f, -35f + pose * 26f + (courierGrounded ? 0f : 18f));
        actor.parts["armB"].localRotation = Quaternion.Euler(0f, 0f, 35f - pose * 26f - (courierGrounded ? 0f : 18f));
        actor.parts["legA"].localRotation = Quaternion.Euler(0f, 0f, 25f + pose2 * 22f + (courierGrounded ? 0f : 14f));
        actor.parts["legB"].localRotation = Quaternion.Euler(0f, 0f, -25f - pose2 * 22f - (courierGrounded ? 0f : 14f));
        actor.parts["scarf"].localRotation = Quaternion.Euler(0f, 0f, -12f + Mathf.Sin(runningTime * 7f) * 14f);
    }

    private void UpdateCat(CartoonActor actor, float speed)
    {
        float absSpeed = Mathf.Max(0.05f, Mathf.Abs(speed));
        float phaseFloat = Mathf.Repeat(runningTime * absSpeed * animationTempo * 7.5f + actor.phaseOffset, 8f);
        int frame = Mathf.FloorToInt(phaseFloat);
        float pose = Mathf.Sin(frame / 8f * Mathf.PI * 2f);
        float pose2 = Mathf.Cos(frame / 8f * Mathf.PI * 2f);
        float ping = Mathf.PingPong(runningTime * absSpeed * 1.1f + actor.phaseOffset, actor.pathWidth) - actor.pathWidth * 0.5f;
        bool reverse = Mathf.FloorToInt((runningTime * absSpeed * 1.1f + actor.phaseOffset) / actor.pathWidth) % 2 == 1;
        actor.root.transform.localPosition = new Vector3(ping, actor.basePosition.y + Mathf.Abs(pose) * 0.045f, 0f);
        actor.root.transform.localScale = new Vector3(reverse ? -0.95f : 0.95f, 0.95f, 1f);
        actor.parts["body"].localRotation = Quaternion.Euler(0f, 0f, pose * 3f);
        actor.parts["head"].localRotation = Quaternion.Euler(0f, 0f, -pose * 4f);
        actor.parts["tail"].localRotation = Quaternion.Euler(0f, 0f, -58f + pose2 * 23f);
        actor.parts["legA"].localRotation = Quaternion.Euler(0f, 0f, 8f + pose * 18f);
        actor.parts["legB"].localRotation = Quaternion.Euler(0f, 0f, -8f - pose * 18f);
        actor.parts["legC"].localRotation = Quaternion.Euler(0f, 0f, 8f - pose2 * 18f);
        actor.parts["eye"].localScale = Vector3.one * (1f + Mathf.Abs(Mathf.Sin(runningTime * 5f)) * 0.22f);
    }

    private void UpdateBird(CartoonActor actor, float speed)
    {
        float absSpeed = Mathf.Max(0.05f, Mathf.Abs(speed));
        float x = Mathf.Repeat(runningTime * speed * 1.75f + actor.phaseOffset + actor.pathWidth * 0.5f, actor.pathWidth) - actor.pathWidth * 0.5f;
        float y = actor.basePosition.y + Mathf.Sin(runningTime * 1.5f + actor.phaseOffset) * 0.55f;
        float phaseFloat = Mathf.Repeat(runningTime * absSpeed * animationTempo * 10f + actor.phaseOffset, 8f);
        int frame = Mathf.FloorToInt(phaseFloat);
        float pose = Mathf.Sin(frame / 8f * Mathf.PI * 2f);
        actor.root.transform.localPosition = new Vector3(x, y, 0f);
        actor.root.transform.localScale = new Vector3(speed >= 0f ? 1.0f : -1.0f, 1.0f, 1f);
        actor.parts["wingA"].localRotation = Quaternion.Euler(0f, 0f, 18f + pose * 42f);
        actor.parts["wingB"].localRotation = Quaternion.Euler(0f, 0f, 162f - pose * 42f);
        actor.parts["tail"].localRotation = Quaternion.Euler(0f, 0f, -90f + pose * 8f);
        actor.root.transform.localRotation = Quaternion.Euler(0f, 0f, Mathf.Sin(runningTime * 1.2f) * 5f);
    }

    private void UpdateLightingAndCamera(float dt)
    {
        // dayNight = 0 — ночь, 1 — рассвет. Меняется фон и контраст, но остаётся рисованный стиль.
        Color night = C("#07102AFF");
        Color dawn = C("#7E9FD6FF");
        sceneCamera.backgroundColor = Color.Lerp(night, dawn, dayNight);
        foreach (SpriteRenderer r in dayTintObjects)
        {
            if (r != null) r.color = Color.Lerp(Color.white, C("#FFE2B5FF"), dayNight * 0.45f);
        }
        sceneCamera.orthographicSize = Mathf.Lerp(sceneCamera.orthographicSize, 5.5f / Mathf.Max(0.6f, globalScale), 1f - Mathf.Exp(-dt * 4f));
    }

    private void ApplyDemoControl(float dt)
    {
        float t = runningTime;
        viewX = Mathf.Lerp(viewX, Mathf.Sin(t * 0.37f) * 4.6f, dt * 0.75f);
        viewY = Mathf.Lerp(viewY, Mathf.Sin(t * 0.31f + 1.2f) * 1.5f, dt * 0.75f);
        catSpeed = Mathf.Lerp(catSpeed, 0.45f + Sin01(t * 0.35f + 0.8f) * 1.05f, dt * 0.7f);
        birdSpeed = Mathf.Lerp(birdSpeed, 0.6f + Sin01(t * 0.49f + 2.0f) * 1.6f, dt * 0.7f);
        lanternWind = Mathf.Lerp(lanternWind, 0.15f + Sin01(t * 0.6f) * 1.25f, dt * 0.65f);
        dayNight = Mathf.Lerp(dayNight, Sin01(t * 0.18f) * 0.75f, dt * 0.35f);
        animationTempo = Mathf.Lerp(animationTempo, 0.75f + Sin01(t * 0.27f) * 0.85f, dt * 0.4f);
    }

    private float Sin01(float x) { return 0.5f + 0.5f * Mathf.Sin(x); }

    private void OnGUI()
    {
        EnsureGuiStyles();
        GUI.depth = -1000;

        GUILayout.BeginArea(new Rect(14, 14, 340, 405), GUIContent.none, GUI.skin.window);
        GUILayout.Label("Контрольная работа №4", titleStyle);
        GUILayout.Space(6);

        courierSpeed = SliderRow("1. Скорость клавиатурного управления курьером", courierSpeed, 0.5f, 2.5f, "");
        catSpeed = SliderRow("2. Скорость кота-робота", catSpeed, 0.0f, 2.1f, "");
        birdSpeed = SliderRow("3. Скорость птицы-дрона", birdSpeed, -2.4f, 2.4f, "");
        viewX = SliderRow("4. Точка взгляда X", viewX, -6.0f, 6.0f, "");
        viewY = SliderRow("5. Точка взгляда Y", viewY, -2.4f, 2.4f, "");
        lanternWind = SliderRow("6. Ветер и фонари", lanternWind, 0.0f, 1.6f, "");
        animationTempo = SliderRow("7. Темп фаз анимации", animationTempo, 0.25f, 2.0f, "");
        dayNight = SliderRow("8. Освещение сцены", dayNight, 0.0f, 1.0f, "");
        globalScale = SliderRow("9. Масштаб сцены", globalScale, 0.72f, 1.35f, "");

        GUILayout.Space(6);
        GUILayout.BeginHorizontal();
        if (GUILayout.Button(demoMode ? "Демонстрация: вкл" : "Демонстрация: выкл")) demoMode = !demoMode;
        if (GUILayout.Button(paused ? "Продолжить" : "Пауза")) paused = !paused;
        GUILayout.EndHorizontal();
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Сброс")) ResetControls();
        if (GUILayout.Button(showDepthGuides ? "Скрыть параллакс" : "Показать параллакс")) showDepthGuides = !showDepthGuides;
        GUILayout.EndHorizontal();
        GUILayout.EndArea();
    }

    private void ResetControls()
    {
        viewX = 0f;
        viewY = 0f;
        courierSpeed = 1.0f;
        catSpeed = 0.72f;
        birdSpeed = 0.92f;
        lanternWind = 0.55f;
        globalScale = 1.0f;
        dayNight = 0.18f;
        animationTempo = 1.0f;
        courierKeyboardOffset = Vector2.zero;
        courierKeyboardActivity = 0f;
        courierKeyboardDirection = 1f;
        courierKeyboardSpin = 0f;
        courierJumpHeight = 0f;
        courierJumpVelocity = 0f;
        courierGrounded = true;
        demoMode = false;
        paused = false;
    }

    private void EnsureGuiStyles()
    {
        if (smallStyle != null) return;
        smallStyle = new GUIStyle(GUI.skin.label);
        smallStyle.fontSize = 12;
        smallStyle.wordWrap = true;
        smallStyle.normal.textColor = C("#EAF7FFFF");

        titleStyle = new GUIStyle(GUI.skin.label);
        titleStyle.fontSize = 17;
        titleStyle.fontStyle = FontStyle.Bold;
        titleStyle.wordWrap = true;
        titleStyle.normal.textColor = C("#FFFFFFFF");

        valueStyle = new GUIStyle(GUI.skin.label);
        valueStyle.fontSize = 13;
        valueStyle.fontStyle = FontStyle.Bold;
        valueStyle.normal.textColor = C("#FFE9A8FF");
    }

    private float SliderRow(string label, float value, float min, float max, string suffix)
    {
        GUILayout.Label(label + ": " + value.ToString("0.00") + suffix, valueStyle);
        return GUILayout.HorizontalSlider(value, min, max);
    }

    private SpriteRenderer AddRect(Transform parent, string name, Vector2 pos, Vector2 size, Color color, int order, float zRot = 0f)
    {
        return AddSprite(parent, name, rectSprite, pos, size, color, order, zRot);
    }

    private SpriteRenderer AddEllipse(Transform parent, string name, Vector2 pos, Vector2 size, Color color, int order, float zRot = 0f)
    {
        return AddSprite(parent, name, circleSprite, pos, size, color, order, zRot);
    }

    private SpriteRenderer AddTriangle(Transform parent, string name, Vector2 pos, Vector2 size, Color color, int order, float zRot = 0f)
    {
        return AddSprite(parent, name, triangleSprite, pos, size, color, order, zRot);
    }

    private SpriteRenderer AddDiamond(Transform parent, string name, Vector2 pos, Vector2 size, Color color, int order, float zRot = 0f)
    {
        return AddSprite(parent, name, diamondSprite, pos, size, color, order, zRot);
    }

    private SpriteRenderer AddSprite(Transform parent, string name, Sprite sprite, Vector2 pos, Vector2 size, Color color, int order, float zRot = 0f)
    {
        GameObject g = new GameObject(name);
        g.transform.SetParent(parent, false);
        // z дополнительно дублирует порядок sortingOrder: более высокий визуальный слой
        // находится ближе к камере. Так столб гарантированно виден перед курьером.
        g.transform.localPosition = new Vector3(pos.x, pos.y, -order * 0.001f);
        g.transform.localRotation = Quaternion.Euler(0f, 0f, zRot);
        g.transform.localScale = new Vector3(size.x, size.y, 1f);
        SpriteRenderer sr = g.AddComponent<SpriteRenderer>();
        sr.sprite = sprite;
        sr.color = color;
        sr.sortingOrder = order;
        Material material = GetSafeSpriteMaterial();
        if (material != null) sr.sharedMaterial = material;
        return sr;
    }

    private Material GetSafeSpriteMaterial()
    {
        if (safeSpriteMaterial != null) return safeSpriteMaterial;

        // Розовый цвет в Unity означает, что шейдер материала не найден или не поддерживается.
        // Поэтому сначала используется собственный шейдер проекта, а затем несколько
        // стандартных резервных шейдеров для Built-in/URP.
        string[] shaderNames =
        {
            "KR4/SafeSpriteUnlit",
            "Sprites/Default",
            "Universal Render Pipeline/2D/Sprite-Unlit-Default",
            "Universal Render Pipeline/Unlit",
            "Unlit/Transparent",
            "UI/Default"
        };

        foreach (string shaderName in shaderNames)
        {
            Shader shader = Shader.Find(shaderName);
            if (shader != null && shader.isSupported)
            {
                safeSpriteMaterial = new Material(shader);
                safeSpriteMaterial.name = "KR4_Runtime_Safe_Sprite_Material";
                safeSpriteMaterial.hideFlags = HideFlags.DontSave;
                return safeSpriteMaterial;
            }
        }

        return null;
    }

    private TextMesh AddWorldText(Transform parent, string text, Vector2 pos, int order, float scale)
    {
        GameObject g = new GameObject("подпись: " + text.Substring(0, Mathf.Min(18, text.Length)));
        g.transform.SetParent(parent, false);
        g.transform.localPosition = new Vector3(pos.x, pos.y, 0f);
        g.transform.localScale = Vector3.one * scale;
        TextMesh mesh = g.AddComponent<TextMesh>();
        mesh.text = text;
        mesh.anchor = TextAnchor.MiddleLeft;
        mesh.alignment = TextAlignment.Left;
        mesh.fontSize = 42;
        mesh.color = C("#EAF7FFFF");
        MeshRenderer mr = g.GetComponent<MeshRenderer>();
        if (mr != null) mr.sortingOrder = order;
        return mesh;
    }

    private Sprite MakeRectSprite(Color color)
    {
        Texture2D t = new Texture2D(1, 1, TextureFormat.RGBA32, false);
        t.wrapMode = TextureWrapMode.Clamp;
        t.filterMode = FilterMode.Bilinear;
        t.SetPixel(0, 0, color);
        t.Apply();
        t.name = "процедурный_пиксель";
        return Sprite.Create(t, new Rect(0, 0, 1, 1), new Vector2(0.5f, 0.5f), 1f);
    }

    private Sprite MakeCircleSprite(int size, Color color, float soft)
    {
        Texture2D t = new Texture2D(size, size, TextureFormat.RGBA32, false);
        t.wrapMode = TextureWrapMode.Clamp;
        t.filterMode = FilterMode.Bilinear;
        float r = size * 0.5f - 1f;
        Vector2 c = new Vector2(size * 0.5f, size * 0.5f);
        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                float d = Vector2.Distance(new Vector2(x, y), c);
                float alpha = 1f;
                if (soft > 0f) alpha = Mathf.Clamp01((r - d) / (r * soft));
                else alpha = d <= r ? 1f : 0f;
                Color p = color;
                p.a *= alpha;
                t.SetPixel(x, y, p);
            }
        }
        t.Apply();
        t.name = "процедурный_круг";
        return Sprite.Create(t, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), size);
    }

    private Sprite MakeTriangleSprite(int size, Color color)
    {
        Texture2D t = new Texture2D(size, size, TextureFormat.RGBA32, false);
        t.wrapMode = TextureWrapMode.Clamp;
        t.filterMode = FilterMode.Bilinear;
        for (int y = 0; y < size; y++)
        {
            float half = (y / (float)(size - 1)) * size * 0.5f;
            float center = size * 0.5f;
            for (int x = 0; x < size; x++)
            {
                bool inside = Mathf.Abs(x - center) <= half && y > 2;
                t.SetPixel(x, y, inside ? color : new Color(0, 0, 0, 0));
            }
        }
        t.Apply();
        t.name = "процедурный_треугольник";
        return Sprite.Create(t, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), size);
    }

    private Sprite MakeDiamondSprite(int size, Color color)
    {
        Texture2D t = new Texture2D(size, size, TextureFormat.RGBA32, false);
        t.wrapMode = TextureWrapMode.Clamp;
        t.filterMode = FilterMode.Bilinear;
        float c = size * 0.5f;
        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                float dx = Mathf.Abs(x - c) / c;
                float dy = Mathf.Abs(y - c) / c;
                bool inside = dx + dy <= 0.96f;
                t.SetPixel(x, y, inside ? color : new Color(0, 0, 0, 0));
            }
        }
        t.Apply();
        t.name = "процедурный_ромб";
        return Sprite.Create(t, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), size);
    }

    private Sprite MakeVerticalGradientSprite(int w, int h, Color top, Color bottom)
    {
        Texture2D t = new Texture2D(w, h, TextureFormat.RGBA32, false);
        t.wrapMode = TextureWrapMode.Clamp;
        t.filterMode = FilterMode.Bilinear;
        for (int y = 0; y < h; y++)
        {
            Color c = Color.Lerp(bottom, top, y / (float)(h - 1));
            for (int x = 0; x < w; x++) t.SetPixel(x, y, c);
        }
        t.Apply();
        t.name = "процедурный_градиент";
        return Sprite.Create(t, new Rect(0, 0, w, h), new Vector2(0.5f, 0.5f), Mathf.Max(w, h));
    }

    private Color C(string html)
    {
        Color c;
        if (ColorUtility.TryParseHtmlString(html, out c)) return c;
        return Color.white;
    }

    private class CartoonLayer
    {
        public GameObject root;
        public float parallax;
        public Vector2 basePosition;
    }

    private class CartoonActor
    {
        public string name;
        public string kind;
        public GameObject root;
        public Vector2 basePosition;
        public float pathWidth;
        public float phaseOffset;
        public Dictionary<string, Transform> parts;
    }
}
