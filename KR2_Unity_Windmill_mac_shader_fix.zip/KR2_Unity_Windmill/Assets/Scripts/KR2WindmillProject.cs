using System.Collections.Generic;
using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
#endif

/// <summary>
/// Контрольная работа №2 по компьютерной графике.
/// Unity-реализация технической системы: ветряная мельница с редуктором и жерновами.
///
/// Проект намеренно сделан одним самодостаточным скриптом: сцена, 3D-объект,
/// интерфейс, режим демонстрации и математическая модель создаются при запуске.
/// Нажмите Play в пустой сцене — модель появится автоматически.
/// </summary>
public class KR2WindmillProject : MonoBehaviour
{
    // Управляемые переменные — «рычаги» пульта.
    private float windPower = 0.62f;       // 0..1
    private float bladePitch = 27f;        // градусы
    private float gearRatio = 1.65f;       // передаточное отношение
    private float grainFlow = 0.48f;       // 0..1
    private float stonePressure = 0.58f;   // 0..1
    private float cameraOrbit = 32f;       // градусы
    private float cameraHeight = 4.4f;     // метры сцены
    private float cameraDistance = 12.0f;  // метры сцены
    private float cutaway = 0.35f;         // 0..1, прозрачность корпуса

    // Режимы и состояние.
    private bool demoMode = false;
    private bool paused = false;
    private bool bodyVisible = true;
    private bool showLinks = true;
    private bool showHelp = true;
    private float flourFill = 0.18f;
    private float runningTime = 0f;

    // Выходные переменные математической модели.
    private float bladeRPM;
    private float gearDriveRPM;
    private float gearDrivenRPM;
    private float millstoneRPM;
    private float flourRate;

    // Трансформы элементов технического устройства.
    private Transform sceneRoot;
    private Transform rotor;
    private Transform axle;
    private Transform gearDrive;
    private Transform gearDriven;
    private Transform verticalShaft;
    private Transform millstoneTop;
    private Transform hopperGate;
    private Transform flourLevel;
    private Transform body;
    private Transform roofLeft;
    private Transform roofRight;
    private Camera mainCamera;

    private readonly List<Transform> grainDots = new List<Transform>();
    private readonly List<Transform> windArrows = new List<Transform>();
    private readonly List<Transform> labels = new List<Transform>();
    private readonly List<GameObject> linkObjects = new List<GameObject>();

    // Материалы.
    private Material woodMat;
    private Material darkWoodMat;
    private Material metalMat;
    private Material stoneMat;
    private Material bodyMat;
    private Material roofMat;
    private Material grainMat;
    private Material flourMat;
    private Material glassMat;
    private Material linkMat;
    private Material windMat;

    private GUIStyle titleStyle;
    private GUIStyle labelStyle;
    private GUIStyle smallStyle;
    private GUIStyle boxStyle;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void AutoCreateOnPlay()
    {
        if (FindObjectOfType<KR2WindmillProject>() == null)
        {
            GameObject host = new GameObject("КР2 Unity — ветряная мельница");
            host.AddComponent<KR2WindmillProject>();
        }
    }

#if UNITY_EDITOR
    [MenuItem("KR2/Создать сцену контрольной работы №2")]
    private static void CreateFromMenu()
    {
        if (FindObjectOfType<KR2WindmillProject>() == null)
        {
            GameObject host = new GameObject("КР2 Unity — ветряная мельница");
            host.AddComponent<KR2WindmillProject>();
            Selection.activeGameObject = host;
        }
    }
#endif

    private void Start()
    {
        Application.targetFrameRate = 60;
        BuildMaterials();
        BuildScene();
    }

    private void Update()
    {
        float dt = paused ? 0f : Time.deltaTime;
        runningTime += Time.deltaTime;

        if (demoMode && !paused)
        {
            ApplyDemoControl(dt);
        }

        UpdateMathematicalModel();
        AnimateMechanism(dt);
        UpdateCutawayMaterials();
        UpdateCamera();
        UpdateBillboardLabels();
    }

    private void OnGUI()
    {
        PrepareGuiStyles();

        GUI.Box(new Rect(10, 10, 390, 690), GUIContent.none, boxStyle);
        GUILayout.BeginArea(new Rect(24, 20, 360, 670));

        GUILayout.Label("Контрольная работа №2", titleStyle);
        GUILayout.Label("Ветряная мельница: 3D-образ, интерфейс, управление", labelStyle);
        GUILayout.Space(6);

        GUILayout.Label("Пульт управления", titleStyle);
        windPower = SliderRow("1. Сила ветра", windPower, 0f, 1f, "");
        bladePitch = SliderRow("2. Угол лопастей", bladePitch, 0f, 45f, "°");
        gearRatio = SliderRow("3. Передаточное отношение", gearRatio, 0.6f, 3.0f, "");
        grainFlow = SliderRow("4. Подача зерна", grainFlow, 0f, 1f, "");
        stonePressure = SliderRow("5. Давление жернова", stonePressure, 0f, 1f, "");
        cameraOrbit = SliderRow("6. Орбита камеры", cameraOrbit, 0f, 360f, "°");
        cameraHeight = SliderRow("7. Высота камеры", cameraHeight, 1.5f, 8.0f, "");
        cameraDistance = SliderRow("8. Расстояние камеры", cameraDistance, 7.0f, 18.0f, "");
        cutaway = SliderRow("9. Разрез / прозрачность", cutaway, 0f, 1f, "");

        GUILayout.Space(6);
        GUILayout.BeginHorizontal();
        if (GUILayout.Button(demoMode ? "Демонстрация: ВКЛ" : "Демонстрация: ВЫКЛ", GUILayout.Height(28)))
        {
            demoMode = !demoMode;
        }
        if (GUILayout.Button(paused ? "Продолжить" : "Пауза", GUILayout.Height(28)))
        {
            paused = !paused;
        }
        GUILayout.EndHorizontal();

        GUILayout.BeginHorizontal();
        if (GUILayout.Button(bodyVisible ? "Скрыть корпус" : "Показать корпус", GUILayout.Height(28)))
        {
            bodyVisible = !bodyVisible;
            if (body != null) body.gameObject.SetActive(bodyVisible);
            if (roofLeft != null) roofLeft.gameObject.SetActive(bodyVisible);
            if (roofRight != null) roofRight.gameObject.SetActive(bodyVisible);
        }
        if (GUILayout.Button(showLinks ? "Скрыть связи" : "Показать связи", GUILayout.Height(28)))
        {
            showLinks = !showLinks;
            foreach (GameObject link in linkObjects) link.SetActive(showLinks);
        }
        GUILayout.EndHorizontal();

        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Сброс", GUILayout.Height(28))) ResetControls();
        if (GUILayout.Button(showHelp ? "Скрыть справку" : "Справка", GUILayout.Height(28))) showHelp = !showHelp;
        GUILayout.EndHorizontal();

        GUILayout.Space(8);
        GUILayout.Label("Выходные переменные", titleStyle);
        GUILayout.Label($"RPM лопастей: {bladeRPM:0.0}", smallStyle);
        GUILayout.Label($"RPM ведущей шестерни: {gearDriveRPM:0.0}", smallStyle);
        GUILayout.Label($"RPM ведомой шестерни: {gearDrivenRPM:0.0}", smallStyle);
        GUILayout.Label($"RPM жернова: {millstoneRPM:0.0}", smallStyle);
        GUILayout.Label($"Производительность муки: {flourRate:0.00} усл. ед./с", smallStyle);

        if (showHelp)
        {
            GUILayout.Space(8);
            GUILayout.TextArea(
                "Справка: модель показывает причинно-следственную схему работы мельницы. " +
                "Ветер вращает лопасти, вал передает вращение на пару шестерён, вертикальный вал " +
                "вращает жернов. Подача зерна и давление жернова влияют на поток готовой муки. " +
                "Ручной режим управляется ползунками. В режиме демонстрации параметры плавно меняются автоматически.",
                smallStyle, GUILayout.Height(112));
        }

        GUILayout.EndArea();
    }

    private float SliderRow(string caption, float value, float min, float max, string suffix)
    {
        GUILayout.Label($"{caption}: {value:0.00}{suffix}", smallStyle);
        return GUILayout.HorizontalSlider(value, min, max, GUILayout.Width(340));
    }

    private void PrepareGuiStyles()
    {
        if (titleStyle != null) return;

        titleStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 15,
            fontStyle = FontStyle.Bold,
            normal = { textColor = Color.white }
        };
        labelStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 12,
            wordWrap = true,
            normal = { textColor = new Color(0.9f, 0.95f, 1f, 1f) }
        };
        smallStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 12,
            wordWrap = true,
            normal = { textColor = Color.white }
        };
        boxStyle = new GUIStyle(GUI.skin.box)
        {
            normal = { background = MakeGuiTexture(new Color(0.05f, 0.07f, 0.08f, 0.78f)) }
        };
    }

    private Texture2D MakeGuiTexture(Color color)
    {
        Texture2D tex = new Texture2D(1, 1);
        tex.SetPixel(0, 0, color);
        tex.Apply();
        return tex;
    }

    private void ResetControls()
    {
        windPower = 0.62f;
        bladePitch = 27f;
        gearRatio = 1.65f;
        grainFlow = 0.48f;
        stonePressure = 0.58f;
        cameraOrbit = 32f;
        cameraHeight = 4.4f;
        cameraDistance = 12.0f;
        cutaway = 0.35f;
        flourFill = 0.18f;
        demoMode = false;
        paused = false;
    }

    private void BuildMaterials()
    {
        woodMat = CreateMaterial("Дерево", new Color(0.58f, 0.34f, 0.16f, 1f));
        darkWoodMat = CreateMaterial("Темное дерево", new Color(0.30f, 0.17f, 0.08f, 1f));
        metalMat = CreateMaterial("Металл", new Color(0.55f, 0.58f, 0.60f, 1f));
        stoneMat = CreateMaterial("Камень", new Color(0.42f, 0.42f, 0.42f, 1f));
        bodyMat = CreateMaterial("Корпус", new Color(0.70f, 0.48f, 0.25f, 0.72f));
        roofMat = CreateMaterial("Крыша", new Color(0.42f, 0.08f, 0.05f, 0.82f));
        grainMat = CreateMaterial("Зерно", new Color(0.95f, 0.73f, 0.23f, 1f));
        flourMat = CreateMaterial("Мука", new Color(0.92f, 0.90f, 0.82f, 1f));
        glassMat = CreateMaterial("Полупрозрачный корпус", new Color(0.35f, 0.75f, 1.0f, 0.28f));
        linkMat = CreateMaterial("Связи переменных", new Color(0.1f, 0.95f, 0.55f, 0.75f));
        windMat = CreateMaterial("Ветер", new Color(0.25f, 0.65f, 1.0f, 0.72f));
    }

    private Material CreateMaterial(string materialName, Color color)
    {
        // Розовый цвет в Unity означает, что шейдер материала не найден или не поддерживается.
        // Поэтому проект сначала использует собственный безопасный Unlit-шейдер, а затем
        // несколько стандартных резервных вариантов для Built-in/URP. Это важно при переносе
        // проекта между Windows и macOS.
        Shader shader = GetSafeShader();
        Material mat = new Material(shader) { name = materialName };
        SetMaterialColor(mat, color);

        if (color.a < 0.99f)
        {
            ConfigureTransparentMaterial(mat);
        }
        else
        {
            ConfigureOpaqueMaterial(mat);
        }

        return mat;
    }

    private Shader GetSafeShader()
    {
        string[] shaderNames =
        {
            "KR2/SafeUnlitColor",
            "Universal Render Pipeline/Unlit",
            "Unlit/Color",
            "Standard",
            "Diffuse"
        };

        foreach (string shaderName in shaderNames)
        {
            Shader shader = Shader.Find(shaderName);
            if (shader != null && shader.isSupported)
            {
                return shader;
            }
        }

        return Shader.Find("Hidden/InternalErrorShader");
    }

    private void SetMaterialColor(Material mat, Color color)
    {
        if (mat == null) return;
        if (mat.HasProperty("_Color")) mat.SetColor("_Color", color);
        if (mat.HasProperty("_BaseColor")) mat.SetColor("_BaseColor", color);
        mat.color = color;
    }

    private void ConfigureTransparentMaterial(Material mat)
    {
        if (mat == null) return;

        if (mat.HasProperty("_Mode")) mat.SetFloat("_Mode", 3f);       // Built-in Standard: Transparent
        if (mat.HasProperty("_Surface")) mat.SetFloat("_Surface", 1f); // URP: Transparent
        if (mat.HasProperty("_Blend")) mat.SetFloat("_Blend", 0f);
        if (mat.HasProperty("_SrcBlend")) mat.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
        if (mat.HasProperty("_DstBlend")) mat.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
        if (mat.HasProperty("_ZWrite")) mat.SetInt("_ZWrite", 0);

        mat.DisableKeyword("_ALPHATEST_ON");
        mat.EnableKeyword("_ALPHABLEND_ON");
        mat.DisableKeyword("_ALPHAPREMULTIPLY_ON");
        mat.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");
        mat.renderQueue = 3000;
    }

    private void ConfigureOpaqueMaterial(Material mat)
    {
        if (mat == null) return;

        if (mat.HasProperty("_Mode")) mat.SetFloat("_Mode", 0f);
        if (mat.HasProperty("_Surface")) mat.SetFloat("_Surface", 0f);
        if (mat.HasProperty("_ZWrite")) mat.SetInt("_ZWrite", 1);
        mat.DisableKeyword("_ALPHABLEND_ON");
        mat.DisableKeyword("_SURFACE_TYPE_TRANSPARENT");
        mat.renderQueue = 2000;
    }

    private void BuildScene()
    {
        sceneRoot = new GameObject("Техническая система: ветряная мельница").transform;

        CreatePrimitive(PrimitiveType.Cube, "Площадка основания", sceneRoot,
            new Vector3(0f, -0.05f, 0f), Quaternion.identity, new Vector3(7.0f, 0.10f, 5.5f), stoneMat);
        CreatePrimitive(PrimitiveType.Cube, "Земля", sceneRoot,
            new Vector3(0f, -0.16f, 0f), Quaternion.identity, new Vector3(18f, 0.08f, 14f), CreateMaterial("Трава", new Color(0.18f, 0.42f, 0.16f, 1f)));

        BuildWindmill();
        BuildWindField();
        BuildVariableLinks();
        BuildCameraAndLight();
        UpdateCutawayMaterials();
        UpdateMathematicalModel();
    }

    private void BuildWindmill()
    {
        CreatePrimitive(PrimitiveType.Cylinder, "Башня", sceneRoot,
            new Vector3(0f, 2.0f, 0f), Quaternion.identity, new Vector3(0.58f, 2.0f, 0.58f), woodMat);

        body = CreatePrimitive(PrimitiveType.Cube, "Корпус мельницы / машинное отделение", sceneRoot,
            new Vector3(0f, 4.18f, 0f), Quaternion.identity, new Vector3(2.2f, 1.18f, 1.65f), bodyMat).transform;

        roofLeft = CreatePrimitive(PrimitiveType.Cube, "Левая половина крыши", sceneRoot,
            new Vector3(-0.48f, 4.95f, 0f), Quaternion.Euler(0f, 0f, -22f), new Vector3(1.25f, 0.18f, 1.92f), roofMat).transform;
        roofRight = CreatePrimitive(PrimitiveType.Cube, "Правая половина крыши", sceneRoot,
            new Vector3(0.48f, 4.95f, 0f), Quaternion.Euler(0f, 0f, 22f), new Vector3(1.25f, 0.18f, 1.92f), roofMat).transform;

        rotor = new GameObject("Ротор с лопастями").transform;
        rotor.SetParent(sceneRoot, false);
        rotor.localPosition = new Vector3(0f, 4.22f, -1.02f);
        CreatePrimitive(PrimitiveType.Sphere, "Ступица", rotor, Vector3.zero, Quaternion.identity, new Vector3(0.32f, 0.32f, 0.32f), metalMat);

        for (int i = 0; i < 4; i++)
        {
            float angle = i * 90f;
            Transform blade = CreatePrimitive(PrimitiveType.Cube, "Лопасть " + (i + 1), rotor,
                Quaternion.Euler(0f, 0f, angle) * new Vector3(0f, 0.86f, 0f),
                Quaternion.Euler(0f, 0f, angle),
                new Vector3(0.18f, 1.55f, 0.08f), darkWoodMat).transform;
            CreatePrimitive(PrimitiveType.Cube, "Парус лопасти " + (i + 1), blade,
                new Vector3(0.10f, 0.28f, 0f), Quaternion.identity, new Vector3(0.26f, 0.55f, 0.05f), woodMat);
        }

        axle = CreatePrimitive(PrimitiveType.Cylinder, "Главный горизонтальный вал", sceneRoot,
            new Vector3(0f, 4.22f, -0.38f), Quaternion.Euler(90f, 0f, 0f), new Vector3(0.16f, 0.70f, 0.16f), metalMat).transform;

        gearDrive = CreateGear("Ведущая шестерня", new Vector3(0.55f, 3.72f, -0.22f), 0.48f, 0.18f, 14);
        gearDriven = CreateGear("Ведомая шестерня", new Vector3(-0.12f, 3.05f, -0.22f), 0.72f, 0.18f, 20);

        verticalShaft = CreatePrimitive(PrimitiveType.Cylinder, "Вертикальный вал", sceneRoot,
            new Vector3(-0.12f, 2.0f, -0.22f), Quaternion.identity, new Vector3(0.14f, 1.05f, 0.14f), metalMat).transform;

        CreatePrimitive(PrimitiveType.Cylinder, "Нижний неподвижный жернов", sceneRoot,
            new Vector3(-0.12f, 0.62f, -0.22f), Quaternion.identity, new Vector3(1.18f, 0.16f, 1.18f), stoneMat);
        millstoneTop = CreatePrimitive(PrimitiveType.Cylinder, "Верхний вращающийся жернов", sceneRoot,
            new Vector3(-0.12f, 0.88f, -0.22f), Quaternion.identity, new Vector3(1.08f, 0.14f, 1.08f), stoneMat).transform;

        Transform hopper = CreateTruncatedPyramid("Бункер подачи зерна", sceneRoot,
            new Vector3(0.78f, 1.83f, -0.20f), 0.42f, 1.05f, 1.15f, woodMat).transform;
        hopperGate = CreatePrimitive(PrimitiveType.Cube, "Заслонка бункера", hopper,
            new Vector3(0f, -0.68f, 0f), Quaternion.identity, new Vector3(0.58f, 0.07f, 0.58f), metalMat).transform;

        CreatePrimitive(PrimitiveType.Cube, "Накопитель муки", sceneRoot,
            new Vector3(-2.38f, 0.45f, -1.55f), Quaternion.identity, new Vector3(1.38f, 0.9f, 1.05f), glassMat);
        flourLevel = CreatePrimitive(PrimitiveType.Cube, "Уровень муки", sceneRoot,
            new Vector3(-2.38f, 0.24f, -1.55f), Quaternion.identity, new Vector3(1.18f, 0.18f, 0.86f), flourMat).transform;

        for (int i = 0; i < 15; i++)
        {
            Transform dot = CreatePrimitive(PrimitiveType.Sphere, "Зерно " + (i + 1), sceneRoot,
                Vector3.zero, Quaternion.identity, new Vector3(0.055f, 0.055f, 0.055f), grainMat).transform;
            grainDots.Add(dot);
        }

        CreateWorldLabel("Ветер → лопасти", new Vector3(-2.8f, 5.2f, -1.8f));
        CreateWorldLabel("Редуктор", new Vector3(1.25f, 3.65f, -0.55f));
        CreateWorldLabel("Жернова", new Vector3(-1.55f, 0.95f, -0.75f));
        CreateWorldLabel("Поток зерна", new Vector3(1.7f, 1.85f, -0.55f));
    }

    private Transform CreateGear(string gearName, Vector3 position, float radius, float thickness, int teeth)
    {
        Transform gear = new GameObject(gearName).transform;
        gear.SetParent(sceneRoot, false);
        gear.localPosition = position;

        CreatePrimitive(PrimitiveType.Cylinder, gearName + " — диск", gear,
            Vector3.zero, Quaternion.identity, new Vector3(radius * 2f, thickness, radius * 2f), metalMat);

        for (int i = 0; i < teeth; i++)
        {
            float a = i * Mathf.PI * 2f / teeth;
            Vector3 pos = new Vector3(Mathf.Cos(a) * (radius + 0.08f), 0f, Mathf.Sin(a) * (radius + 0.08f));
            CreatePrimitive(PrimitiveType.Cube, gearName + " — зуб " + (i + 1), gear,
                pos, Quaternion.Euler(0f, -a * Mathf.Rad2Deg, 0f), new Vector3(0.16f, thickness * 1.1f, 0.23f), metalMat);
        }

        return gear;
    }

    private void BuildWindField()
    {
        for (int i = 0; i < 5; i++)
        {
            Transform arrow = new GameObject("Стрелка ветра " + (i + 1)).transform;
            arrow.SetParent(sceneRoot, false);
            arrow.localPosition = new Vector3(-2.8f + i * 0.25f, 3.25f + i * 0.34f, -5.4f);
            CreatePrimitive(PrimitiveType.Cube, "Корпус стрелки ветра", arrow,
                Vector3.zero, Quaternion.identity, new Vector3(0.08f, 0.08f, 0.85f), windMat);
            CreatePrimitive(PrimitiveType.Sphere, "Голова стрелки ветра", arrow,
                new Vector3(0f, 0f, 0.52f), Quaternion.identity, new Vector3(0.22f, 0.22f, 0.22f), windMat);
            windArrows.Add(arrow);
        }
    }

    private void BuildVariableLinks()
    {
        // Зеленые связи показывают, как переменные передаются по технической системе.
        linkObjects.Add(CreateLink("Связь: ротор → вал", new Vector3(0f, 4.22f, -0.95f), new Vector3(0f, 4.22f, -0.05f)));
        linkObjects.Add(CreateLink("Связь: вал → ведущая шестерня", new Vector3(0f, 4.22f, -0.05f), new Vector3(0.55f, 3.72f, -0.22f)));
        linkObjects.Add(CreateLink("Связь: ведущая → ведомая шестерня", new Vector3(0.55f, 3.72f, -0.22f), new Vector3(-0.12f, 3.05f, -0.22f)));
        linkObjects.Add(CreateLink("Связь: ведомая → вертикальный вал", new Vector3(-0.12f, 3.05f, -0.22f), new Vector3(-0.12f, 1.15f, -0.22f)));
        linkObjects.Add(CreateLink("Связь: вал → жернова", new Vector3(-0.12f, 1.15f, -0.22f), new Vector3(-0.12f, 0.88f, -0.22f)));
        linkObjects.Add(CreateLink("Связь: зерно → мука", new Vector3(0.78f, 1.25f, -0.20f), new Vector3(-2.38f, 0.45f, -1.55f)));
    }

    private GameObject CreateLink(string linkName, Vector3 a, Vector3 b)
    {
        GameObject link = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        link.name = linkName;
        link.transform.SetParent(sceneRoot, false);
        Vector3 mid = (a + b) * 0.5f;
        Vector3 dir = b - a;
        link.transform.localPosition = mid;
        link.transform.localRotation = Quaternion.FromToRotation(Vector3.up, dir.normalized);
        link.transform.localScale = new Vector3(0.035f, dir.magnitude * 0.5f, 0.035f);
        link.GetComponent<Renderer>().material = linkMat;
        Destroy(link.GetComponent<Collider>());
        return link;
    }

    private void BuildCameraAndLight()
    {
        GameObject light = new GameObject("Солнце / направленный свет");
        Light sun = light.AddComponent<Light>();
        sun.type = LightType.Directional;
        sun.intensity = 1.15f;
        light.transform.rotation = Quaternion.Euler(50f, -35f, 0f);

        GameObject fill = new GameObject("Заполняющий свет");
        Light fillLight = fill.AddComponent<Light>();
        fillLight.type = LightType.Point;
        fillLight.intensity = 1.4f;
        fillLight.range = 10f;
        fill.transform.position = new Vector3(-4f, 5f, -4f);

        GameObject camGo = new GameObject("Камера");
        mainCamera = camGo.AddComponent<Camera>();
        mainCamera.fieldOfView = 52f;
        mainCamera.nearClipPlane = 0.05f;
        mainCamera.farClipPlane = 100f;
        mainCamera.backgroundColor = new Color(0.62f, 0.76f, 0.92f, 1f);
        UpdateCamera();
    }

    private void ApplyDemoControl(float dt)
    {
        // Плавная автодемонстрация. Lerp предотвращает рывок при переключении режима.
        float t = runningTime;
        windPower = Mathf.Lerp(windPower, 0.55f + 0.35f * Sin01(t * 0.65f), dt * 0.75f);
        bladePitch = Mathf.Lerp(bladePitch, 12f + 27f * Sin01(t * 0.43f + 1.3f), dt * 0.75f);
        gearRatio = Mathf.Lerp(gearRatio, 1.05f + 1.45f * Sin01(t * 0.31f + 2.1f), dt * 0.55f);
        grainFlow = Mathf.Lerp(grainFlow, 0.25f + 0.65f * Sin01(t * 0.51f + 0.8f), dt * 0.65f);
        stonePressure = Mathf.Lerp(stonePressure, 0.35f + 0.50f * Sin01(t * 0.37f + 1.7f), dt * 0.60f);
        cutaway = Mathf.Lerp(cutaway, 0.55f + 0.35f * Sin01(t * 0.22f), dt * 0.45f);
        cameraOrbit = Mathf.Repeat(cameraOrbit + dt * 10f, 360f);
        cameraHeight = Mathf.Lerp(cameraHeight, 4.5f + 1.0f * Mathf.Sin(t * 0.35f), dt * 0.45f);
    }

    private float Sin01(float x)
    {
        return 0.5f + 0.5f * Mathf.Sin(x);
    }

    private void UpdateMathematicalModel()
    {
        // Связи переменных:
        // ветер + угол лопастей -> обороты ротора;
        // передаточное отношение -> обороты ведомой шестерни;
        // обороты жернова + подача зерна + давление -> производительность муки.
        float pitchFactor = 0.35f + bladePitch / 45f;
        bladeRPM = windPower * pitchFactor * 125f;
        gearDriveRPM = bladeRPM;
        gearDrivenRPM = -gearDriveRPM / Mathf.Max(gearRatio, 0.01f);
        millstoneRPM = Mathf.Abs(gearDrivenRPM) * 0.88f;
        flourRate = grainFlow * stonePressure * Mathf.Clamp01(millstoneRPM / 70f) * 1.35f;
    }

    private void AnimateMechanism(float dt)
    {
        if (dt <= 0f) return;

        float rotorDegPerSec = bladeRPM * 6f;
        float driveDegPerSec = gearDriveRPM * 6f;
        float drivenDegPerSec = gearDrivenRPM * 6f;
        float millDegPerSec = millstoneRPM * 6f;

        if (rotor != null) rotor.Rotate(Vector3.forward, -rotorDegPerSec * dt, Space.Self);
        if (axle != null) axle.Rotate(Vector3.forward, -rotorDegPerSec * dt, Space.Self);
        if (gearDrive != null) gearDrive.Rotate(Vector3.up, driveDegPerSec * dt, Space.Self);
        if (gearDriven != null) gearDriven.Rotate(Vector3.up, drivenDegPerSec * dt, Space.Self);
        if (verticalShaft != null) verticalShaft.Rotate(Vector3.up, drivenDegPerSec * dt, Space.Self);
        if (millstoneTop != null) millstoneTop.Rotate(Vector3.up, millDegPerSec * dt, Space.Self);

        if (hopperGate != null)
        {
            hopperGate.localScale = new Vector3(0.58f, 0.07f, Mathf.Lerp(0.12f, 0.58f, grainFlow));
        }

        flourFill = Mathf.Repeat(flourFill + flourRate * dt * 0.08f, 1f);
        if (flourLevel != null)
        {
            flourLevel.localScale = new Vector3(1.18f, Mathf.Lerp(0.08f, 0.82f, flourFill), 0.86f);
            flourLevel.localPosition = new Vector3(-2.38f, 0.05f + flourLevel.localScale.y * 0.5f, -1.55f);
        }

        AnimateGrain(dt);
        AnimateWindArrows(dt);
    }

    private void AnimateGrain(float dt)
    {
        Vector3 start = new Vector3(0.78f, 1.35f, -0.20f);
        Vector3 end = new Vector3(-0.12f, 1.03f, -0.22f);
        float speed = 0.4f + grainFlow * 2.0f;
        for (int i = 0; i < grainDots.Count; i++)
        {
            Transform dot = grainDots[i];
            bool active = grainFlow > 0.03f;
            dot.gameObject.SetActive(active);
            if (!active) continue;

            float p = Mathf.Repeat(runningTime * speed + i / (float)grainDots.Count, 1f);
            Vector3 pos = Vector3.Lerp(start, end, p);
            pos.y += Mathf.Sin(p * Mathf.PI) * 0.16f;
            dot.localPosition = pos;
            float s = Mathf.Lerp(0.035f, 0.075f, grainFlow);
            dot.localScale = Vector3.one * s;
        }
    }

    private void AnimateWindArrows(float dt)
    {
        for (int i = 0; i < windArrows.Count; i++)
        {
            Transform arrow = windArrows[i];
            float p = Mathf.Repeat(runningTime * (0.17f + windPower * 0.52f) + i * 0.19f, 1f);
            Vector3 pos = arrow.localPosition;
            pos.z = Mathf.Lerp(-5.6f, -1.5f, p);
            pos.x = -2.3f + Mathf.Sin(runningTime * 0.6f + i) * 0.28f;
            arrow.localPosition = pos;
            arrow.localScale = Vector3.one * Mathf.Lerp(0.65f, 1.25f, windPower);
            arrow.gameObject.SetActive(windPower > 0.03f);
        }
    }

    private void UpdateCutawayMaterials()
    {
        float alphaBody = Mathf.Lerp(0.95f, 0.17f, cutaway);
        float alphaRoof = Mathf.Lerp(0.95f, 0.22f, cutaway);
        SetAlpha(bodyMat, alphaBody);
        SetAlpha(roofMat, alphaRoof);
    }

    private void SetAlpha(Material mat, float alpha)
    {
        if (mat == null) return;
        Color c = mat.color;
        c.a = alpha;
        SetMaterialColor(mat, c);
        if (alpha < 0.99f)
        {
            ConfigureTransparentMaterial(mat);
        }
        else
        {
            ConfigureOpaqueMaterial(mat);
        }
    }

    private void UpdateCamera()
    {
        if (mainCamera == null) return;
        float rad = cameraOrbit * Mathf.Deg2Rad;
        Vector3 target = new Vector3(0f, 2.45f, -0.25f);
        Vector3 pos = target + new Vector3(Mathf.Sin(rad) * cameraDistance, cameraHeight, Mathf.Cos(rad) * cameraDistance);
        mainCamera.transform.position = pos;
        mainCamera.transform.LookAt(target + Vector3.up * 0.65f);
    }

    private void UpdateBillboardLabels()
    {
        if (mainCamera == null) return;
        foreach (Transform label in labels)
        {
            if (label == null) continue;
            label.LookAt(mainCamera.transform);
            label.Rotate(0f, 180f, 0f);
        }
    }

    private GameObject CreatePrimitive(PrimitiveType type, string objectName, Transform parent,
        Vector3 localPosition, Quaternion localRotation, Vector3 localScale, Material material)
    {
        GameObject go = GameObject.CreatePrimitive(type);
        go.name = objectName;
        go.transform.SetParent(parent, false);
        go.transform.localPosition = localPosition;
        go.transform.localRotation = localRotation;
        go.transform.localScale = localScale;
        Renderer renderer = go.GetComponent<Renderer>();
        if (renderer != null && material != null) renderer.material = material;
        Collider collider = go.GetComponent<Collider>();
        if (collider != null) Destroy(collider);
        return go;
    }

    private GameObject CreateTruncatedPyramid(string objectName, Transform parent,
        Vector3 localPosition, float topSize, float bottomSize, float height, Material material)
    {
        GameObject go = new GameObject(objectName);
        go.transform.SetParent(parent, false);
        go.transform.localPosition = localPosition;

        float b = bottomSize * 0.5f;
        float t = topSize * 0.5f;
        float h = height * 0.5f;

        Mesh mesh = new Mesh();
        mesh.name = objectName + " Mesh";
        mesh.vertices = new[]
        {
            new Vector3(-b, -h, -b), new Vector3(b, -h, -b), new Vector3(b, -h, b), new Vector3(-b, -h, b),
            new Vector3(-t, h, -t), new Vector3(t, h, -t), new Vector3(t, h, t), new Vector3(-t, h, t)
        };
        mesh.triangles = new[]
        {
            0, 1, 2, 0, 2, 3,
            4, 6, 5, 4, 7, 6,
            0, 4, 5, 0, 5, 1,
            1, 5, 6, 1, 6, 2,
            2, 6, 7, 2, 7, 3,
            3, 7, 4, 3, 4, 0
        };
        mesh.RecalculateNormals();
        mesh.RecalculateBounds();

        MeshFilter mf = go.AddComponent<MeshFilter>();
        mf.sharedMesh = mesh;
        MeshRenderer mr = go.AddComponent<MeshRenderer>();
        mr.material = material;
        return go;
    }

    private void CreateWorldLabel(string text, Vector3 pos)
    {
        GameObject go = new GameObject("Подпись: " + text);
        go.transform.SetParent(sceneRoot, false);
        go.transform.localPosition = pos;
        TextMesh tm = go.AddComponent<TextMesh>();
        tm.text = text;
        tm.fontSize = 42;
        tm.characterSize = 0.055f;
        tm.anchor = TextAnchor.MiddleCenter;
        tm.alignment = TextAlignment.Center;
        tm.color = new Color(0.02f, 0.05f, 0.08f, 1f);
        labels.Add(go.transform);
    }
}
